﻿using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MouseHover : MonoBehaviour {


    public Canvas MainCanvas;
    public Button nightmare;


    private void Start()
    {
        nightmare = nightmare.GetComponent<Button>();
    }


    private void Update()
    {
        if (nightmare.isActiveAndEnabled == false)
        {
            SceneManager.LoadScene("MyGame");
        }
    }
}
